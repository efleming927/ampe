import { useState, useEffect } from "react";

const KNOWN = { 3: 0, 4: 4, 5: 5, 6: 11, 7: 13, 8: 22, 9: 25 };

const GH_RED = "#CE1126";
const GH_GOLD = "#FCD116";
const GH_GREEN = "#006B3F";
const GH_BLACK = "#1a1208";

const PLAYER_COLORS = [
  GH_RED,
  GH_GOLD,
  GH_GREEN,
  GH_RED,
  GH_GOLD,
  GH_GREEN,
  GH_RED,
  GH_GOLD,
  GH_GREEN,
];

function isGoal(middle, seats) {
  if (middle !== 1) return false;
  const n = seats.length + 1;
  const goal = Array.from({ length: seats.length }, (_, i) => n - i);
  const numSeats = seats.length;
  for (let r = 0; r < numSeats; r++) {
    let match = true;
    for (let i = 0; i < numSeats; i++) {
      if (seats[(i + r) % numSeats] !== goal[i]) {
        match = false;
        break;
      }
    }
    if (match) return true;
  }
  return false;
}

function getPos(seatIdx, totalSeats, cx, cy, r) {
  const angle = (seatIdx / totalSeats) * 2 * Math.PI - Math.PI / 2;
  return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
}

function StarIcon({ x, y, size = 10, fill = GH_BLACK }) {
  const pts = [];
  for (let i = 0; i < 5; i++) {
    const outerA = (i * 2 * Math.PI) / 5 - Math.PI / 2;
    const innerA = outerA + Math.PI / 5;
    pts.push(`${x + size * Math.cos(outerA)},${y + size * Math.sin(outerA)}`);
    pts.push(
      `${x + size * 0.4 * Math.cos(innerA)},${
        y + size * 0.4 * Math.sin(innerA)
      }`
    );
  }
  return <polygon points={pts.join(" ")} fill={fill} />;
}

export default function AmpeGame() {
  const [numPlayers, setNumPlayers] = useState(6);
  const [seats, setSeats] = useState([2, 3, 4, 5, 6]);
  const [middle, setMiddle] = useState(1);
  const [opponentSeatIdx, setOpponentSeatIdx] = useState(0);
  const [steps, setSteps] = useState(0);
  const [history, setHistory] = useState([]);
  const [won, setWon] = useState(false);
  const [flash, setFlash] = useState(null);
  const [personalBest, setPersonalBest] = useState({});

  const numSeats = numPlayers - 1;
  const bestKnown = KNOWN[numPlayers] ?? null;

  useEffect(() => {
    resetGame(numPlayers);
  }, [numPlayers]);

  function resetGame(n) {
    setSeats(Array.from({ length: n - 1 }, (_, i) => i + 2));
    setMiddle(1);
    setOpponentSeatIdx(0);
    setSteps(0);
    setHistory([]);
    setWon(false);
    setFlash(null);
  }

  function playGame(winnerIsMiddle) {
    if (won) return;
    const opponent = seats[opponentSeatIdx];
    let newMiddle, newSeats, newOppIdx;
    const nextOppIdx = (opponentSeatIdx + 1) % numSeats;

    if (winnerIsMiddle) {
      newMiddle = middle;
      newSeats = [...seats];
      newOppIdx = nextOppIdx;
      setFlash({ player: middle, type: "win" });
    } else {
      newMiddle = opponent;
      newSeats = [...seats];
      newSeats[opponentSeatIdx] = middle;
      newOppIdx = nextOppIdx;
      setFlash({ player: opponent, type: "win" });
    }

    const newSteps = steps + 1;
    setMiddle(newMiddle);
    setSeats(newSeats);
    setOpponentSeatIdx(newOppIdx);
    setSteps(newSteps);
    setHistory((h) => [
      ...h,
      {
        middle,
        opponent,
        winnerIsMiddle,
        newMiddle,
        newSeats: [...newSeats],
        newOppIdx,
      },
    ]);
    setTimeout(() => setFlash(null), 500);

    if (isGoal(newMiddle, newSeats)) {
      setWon(true);
      setPersonalBest((pb) =>
        !pb[numPlayers] || newSteps < pb[numPlayers]
          ? { ...pb, [numPlayers]: newSteps }
          : pb
      );
    }
  }

  function undo() {
    if (history.length === 0) return;
    if (history.length === 1) {
      resetGame(numPlayers);
      return;
    }
    const newHistory = history.slice(0, -1);
    const last = newHistory[newHistory.length - 1];
    setMiddle(last.newMiddle);
    setSeats([...last.newSeats]);
    setOpponentSeatIdx(last.newOppIdx);
    setSteps(newHistory.length);
    setHistory(newHistory);
    setWon(false);
    setFlash(null);
  }

  const svgSize = 320;
  const cx = svgSize / 2,
    cy = svgSize / 2,
    rCircle = 105;
  const opponent = seats[opponentSeatIdx];

  const oppPos = getPos(opponentSeatIdx, numSeats, cx, cy, rCircle);
  const dx = oppPos.x - cx,
    dy = oppPos.y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const arrowTip = { x: cx + (dx / dist) * 56, y: cy + (dy / dist) * 56 };
  const arrowBase = { x: cx + (dx / dist) * 26, y: cy + (dy / dist) * 26 };
  const perp = { x: -dy / dist, y: dx / dist };
  const hs = 8;

  const middleColor = PLAYER_COLORS[(middle - 1) % PLAYER_COLORS.length];

  // "tap to win" label position for middle — just below the circle edge
  const tapLabelR = 46;

  // For middle player, place "tap to win" below the circle
  const middleTapPos = { x: cx, y: cy + tapLabelR };

  const isOptimal = bestKnown !== null && steps === bestKnown;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: GH_BLACK,
        color: GH_GOLD,
        fontFamily: "'Georgia', 'Times New Roman', serif",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "1.5rem 1rem 3rem",
        backgroundImage: `
        radial-gradient(ellipse at 15% 10%, rgba(206,17,38,0.18) 0%, transparent 55%),
        radial-gradient(ellipse at 85% 85%, rgba(0,107,63,0.18) 0%, transparent 55%),
        radial-gradient(ellipse at 50% 50%, rgba(252,209,22,0.04) 0%, transparent 70%)
      `,
      }}
    >
      {/* HEADER */}
      <div style={{ textAlign: "center", marginBottom: "1.2rem" }}>
        <div
          style={{
            display: "flex",
            height: "5px",
            width: "200px",
            margin: "0 auto 0.9rem",
            borderRadius: "3px",
            overflow: "hidden",
          }}
        >
          <div style={{ flex: 1, background: GH_RED }} />
          <div style={{ flex: 1, background: GH_GOLD }} />
          <div style={{ flex: 1, background: GH_GREEN }} />
        </div>
        <div
          style={{
            fontSize: "0.9rem",
            letterSpacing: "0.4em",
            color: GH_GOLD,
            opacity: 0.7,
            textTransform: "uppercase",
            marginBottom: "0.4rem",
          }}
        >
          ★ The Circle Puzzle ★
        </div>
        <h1
          style={{
            fontSize: "clamp(3.5rem, 10vw, 5rem)",
            fontWeight: "normal",
            margin: 0,
            fontStyle: "italic",
            letterSpacing: "-0.02em",
            background: `linear-gradient(135deg, ${GH_RED}, ${GH_GOLD}, ${GH_GREEN})`,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Ampe
        </h1>
        <p
          style={{
            color: "rgba(252,209,22,0.6)",
            fontSize: "1.15rem",
            margin: "0.35rem 0 0",
            letterSpacing: "0.06em",
            fontStyle: "italic",
          }}
        >
          Reverse the circle
        </p>
      </div>

      {/* INSTRUCTIONS */}
      <div
        style={{
          background: "rgba(252,209,22,0.05)",
          border: "1px solid rgba(252,209,22,0.15)",
          borderRadius: "10px",
          padding: "0.8rem 1.1rem",
          marginBottom: "1.1rem",
          maxWidth: "360px",
          width: "100%",
          textAlign: "center",
        }}
      >
        <div
          style={{
            fontSize: "1.05rem",
            color: "rgba(252,209,22,0.8)",
            lineHeight: 1.6,
          }}
        >
          Choose winner of each game to stay in or move to the middle.
        </div>
        <div
          style={{
            marginTop: "0.5rem",
            fontSize: "1rem",
            color: GH_GOLD,
            fontStyle: "italic",
            lineHeight: 1.6,
          }}
        >
          Aim is to reverse the order of players returning 1 to the middle in
          the fewest moves.
        </div>
      </div>

      {/* PLAYER COUNT */}
      <div
        style={{
          display: "flex",
          gap: "0.5rem",
          marginBottom: "1.1rem",
          alignItems: "center",
        }}
      >
        <span
          style={{
            fontSize: "1rem",
            color: "rgba(252,209,22,0.5)",
            marginRight: "0.4rem",
            letterSpacing: "0.12em",
          }}
        >
          PLAYERS
        </span>
        {[3, 4, 5, 6, 7, 8, 9].map((n) => (
          <button
            key={n}
            onClick={() => setNumPlayers(n)}
            style={{
              width: "40px",
              height: "40px",
              borderRadius: "50%",
              border:
                numPlayers === n
                  ? `2px solid ${GH_GOLD}`
                  : "1px solid rgba(252,209,22,0.2)",
              background: numPlayers === n ? GH_GOLD : "transparent",
              color: numPlayers === n ? GH_BLACK : "rgba(252,209,22,0.45)",
              cursor: "pointer",
              fontSize: "1.05rem",
              fontFamily: "Georgia, serif",
              fontWeight: numPlayers === n ? "bold" : "normal",
              transition: "all 0.2s",
            }}
          >
            {n}
          </button>
        ))}
      </div>

      {/* SVG CIRCLE */}
      <div style={{ position: "relative", marginBottom: "0.6rem" }}>
        <svg
          width={svgSize}
          height={svgSize}
          viewBox={`0 0 ${svgSize} ${svgSize}`}
        >
          {/* Decorative rings */}
          <circle
            cx={cx}
            cy={cy}
            r={rCircle + 22}
            fill="none"
            stroke={GH_RED}
            strokeWidth="3"
            strokeDasharray={`${(2 * Math.PI * (rCircle + 22)) / 3} ${
              (2 * Math.PI * (rCircle + 22)) / 3
            }`}
            strokeDashoffset="0"
            opacity="0.5"
          />
          <circle
            cx={cx}
            cy={cy}
            r={rCircle + 22}
            fill="none"
            stroke={GH_GOLD}
            strokeWidth="3"
            strokeDasharray={`${(2 * Math.PI * (rCircle + 22)) / 3} ${
              (2 * Math.PI * (rCircle + 22)) / 3
            }`}
            strokeDashoffset={`-${(2 * Math.PI * (rCircle + 22)) / 3}`}
            opacity="0.5"
          />
          <circle
            cx={cx}
            cy={cy}
            r={rCircle + 22}
            fill="none"
            stroke={GH_GREEN}
            strokeWidth="3"
            strokeDasharray={`${(2 * Math.PI * (rCircle + 22)) / 3} ${
              (2 * Math.PI * (rCircle + 22)) / 3
            }`}
            strokeDashoffset={`-${(2 * (2 * Math.PI * (rCircle + 22))) / 3}`}
            opacity="0.5"
          />
          <circle
            cx={cx}
            cy={cy}
            r={rCircle - 20}
            fill="none"
            stroke="rgba(252,209,22,0.07)"
            strokeWidth="1"
          />

          {/* Circle players */}
          {seats.map((playerNum, seatIdx) => {
            const pos = getPos(seatIdx, numSeats, cx, cy, rCircle);
            const isOpp = seatIdx === opponentSeatIdx && !won;
            const col = PLAYER_COLORS[(playerNum - 1) % PLAYER_COLORS.length];
            const isFlashing = flash && flash.player === playerNum;
            return (
              <g
                key={`seat-${seatIdx}`}
                onClick={isOpp && !won ? () => playGame(false) : undefined}
                style={{ cursor: isOpp && !won ? "pointer" : "default" }}
              >
                {isOpp && (
                  <>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={28}
                      fill="none"
                      stroke={GH_GOLD}
                      strokeWidth="1"
                      opacity="0.2"
                      strokeDasharray="3 3"
                    />
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={22}
                      fill="rgba(252,209,22,0.07)"
                      stroke={GH_GOLD}
                      strokeWidth="1.8"
                      opacity="0.7"
                    />
                  </>
                )}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={18}
                  fill={
                    isFlashing ? "rgba(252,209,22,0.35)" : "rgba(26,18,8,0.9)"
                  }
                  stroke={col}
                  strokeWidth={isOpp ? 2.5 : 1.8}
                  style={{ transition: "fill 0.3s" }}
                />
                <text
                  x={pos.x}
                  y={pos.y + 1}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="17"
                  fontWeight="bold"
                  fill={col}
                  fontFamily="Georgia, serif"
                >
                  {playerNum}
                </text>
                {isOpp && !won && (
                  <text
                    x={pos.x}
                    y={pos.y + 37}
                    textAnchor="middle"
                    fontSize="10"
                    fill={GH_GOLD}
                    opacity="0.8"
                    fontFamily="Georgia, serif"
                  >
                    tap to win
                  </text>
                )}
              </g>
            );
          })}

          {/* Arrow */}
          {!won && (
            <>
              <line
                x1={arrowBase.x}
                y1={arrowBase.y}
                x2={arrowTip.x}
                y2={arrowTip.y}
                stroke={GH_GOLD}
                strokeWidth="2.5"
                strokeLinecap="round"
                opacity="0.7"
              />
              <polygon
                points={`${arrowTip.x},${arrowTip.y} ${
                  arrowTip.x - (dx / dist) * hs + perp.x * hs * 0.6
                },${arrowTip.y - (dy / dist) * hs + perp.y * hs * 0.6} ${
                  arrowTip.x - (dx / dist) * hs - perp.x * hs * 0.6
                },${arrowTip.y - (dy / dist) * hs - perp.y * hs * 0.6}`}
                fill={GH_GOLD}
                opacity="0.85"
              />
            </>
          )}

          {/* Middle player */}
          <g
            onClick={!won ? () => playGame(true) : undefined}
            style={{ cursor: !won ? "pointer" : "default" }}
          >
            <circle
              cx={cx}
              cy={cy}
              r={32}
              fill={
                flash && flash.player === middle
                  ? "rgba(252,209,22,0.25)"
                  : "rgba(26,18,8,0.95)"
              }
              stroke={middleColor}
              strokeWidth="2.5"
              style={{ transition: "fill 0.3s" }}
            />
            <StarIcon x={cx} y={cy - 9} size={11} fill={middleColor} />
            <text
              x={cx}
              y={cy + 11}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize="18"
              fontWeight="bold"
              fill={middleColor}
              fontFamily="Georgia, serif"
            >
              {middle}
            </text>
            {/* tap to win label outside the circle */}
            {!won && (
              <text
                x={middleTapPos.x}
                y={middleTapPos.y + 12}
                textAnchor="middle"
                fontSize="10"
                fill={middleColor}
                opacity="0.7"
                fontFamily="Georgia, serif"
              >
                tap to win
              </text>
            )}
          </g>
        </svg>

        {/* Win overlay */}
        {won && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              background: "rgba(26,18,8,0.92)",
              borderRadius: "50%",
              backdropFilter: "blur(3px)",
            }}
          >
            <div style={{ fontSize: "2.2rem" }}>★</div>
            <div
              style={{
                color: GH_GOLD,
                fontSize: "1.5rem",
                fontStyle: "italic",
                marginBottom: "0.2rem",
              }}
            >
              Solved!
            </div>
            <div
              style={{
                color: GH_GOLD,
                fontSize: "3rem",
                fontWeight: "bold",
                lineHeight: 1,
              }}
            >
              {steps}
            </div>
            <div
              style={{
                color: "rgba(252,209,22,0.5)",
                fontSize: "0.9rem",
                letterSpacing: "0.12em",
                marginBottom: "0.3rem",
              }}
            >
              GAMES
            </div>
            <div
              style={{
                fontSize: "1.1rem",
                fontStyle: "italic",
                color: isOptimal ? GH_GREEN : GH_RED,
                fontWeight: "bold",
              }}
            >
              {isOptimal ? "Optimal solution" : "Not optimal"}
            </div>
          </div>
        )}
      </div>

      {/* SCORE ROW */}
      <div
        style={{
          display: "flex",
          gap: "2rem",
          alignItems: "center",
          marginBottom: "1rem",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              fontSize: "2.8rem",
              fontWeight: "bold",
              color: GH_GOLD,
              lineHeight: 1,
            }}
          >
            {steps}
          </div>
          <div
            style={{
              fontSize: "0.85rem",
              color: "rgba(252,209,22,0.4)",
              letterSpacing: "0.15em",
            }}
          >
            GAMES
          </div>
        </div>
        {personalBest[numPlayers] && (
          <>
            <div
              style={{
                width: "1px",
                height: "32px",
                background: "rgba(252,209,22,0.15)",
              }}
            />
            <div style={{ textAlign: "center" }}>
              <div
                style={{
                  fontSize: "2.8rem",
                  fontWeight: "bold",
                  color: GH_GREEN,
                  lineHeight: 1,
                }}
              >
                {personalBest[numPlayers]}
              </div>
              <div
                style={{
                  fontSize: "0.85rem",
                  color: "rgba(252,209,22,0.4)",
                  letterSpacing: "0.15em",
                }}
              >
                YOUR BEST
              </div>
            </div>
          </>
        )}
      </div>

      {/* UNDO / RESET / PLAY AGAIN */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "0.6rem",
          width: "100%",
          maxWidth: "360px",
        }}
      >
        {!won ? (
          <div style={{ display: "flex", gap: "0.6rem" }}>
            <button
              onClick={undo}
              disabled={history.length === 0}
              style={{
                flex: 1,
                padding: "0.6rem",
                background: "transparent",
                border: "1px solid rgba(252,209,22,0.15)",
                borderRadius: "8px",
                color:
                  history.length === 0
                    ? "rgba(252,209,22,0.15)"
                    : "rgba(252,209,22,0.5)",
                fontSize: "1rem",
                fontFamily: "Georgia, serif",
                cursor: history.length === 0 ? "not-allowed" : "pointer",
              }}
            >
              ← Undo
            </button>
            <button
              onClick={() => resetGame(numPlayers)}
              style={{
                flex: 1,
                padding: "0.6rem",
                background: "transparent",
                border: "1px solid rgba(252,209,22,0.15)",
                borderRadius: "8px",
                color: "rgba(252,209,22,0.5)",
                fontSize: "1rem",
                fontFamily: "Georgia, serif",
                cursor: "pointer",
              }}
            >
              ↺ Reset
            </button>
          </div>
        ) : (
          <button
            onClick={() => resetGame(numPlayers)}
            style={{
              padding: "0.9rem 2rem",
              background:
                "linear-gradient(135deg, rgba(252,209,22,0.15), rgba(252,209,22,0.25))",
              border: `1.5px solid ${GH_GOLD}`,
              borderRadius: "10px",
              color: GH_GOLD,
              fontSize: "1.1rem",
              fontFamily: "Georgia, serif",
              cursor: "pointer",
            }}
          >
            ↺ Play Again
          </button>
        )}

        {/* History */}
        {history.length > 0 && (
          <div
            style={{
              background: "rgba(252,209,22,0.04)",
              border: "1px solid rgba(252,209,22,0.1)",
              borderRadius: "10px",
              padding: "0.7rem",
              maxHeight: "130px",
              overflowY: "auto",
            }}
          >
            <div
              style={{
                fontSize: "0.75rem",
                color: "rgba(252,209,22,0.35)",
                letterSpacing: "0.2em",
                marginBottom: "0.4rem",
              }}
            >
              HISTORY
            </div>
            {history.map((h, i) => (
              <div
                key={i}
                style={{
                  display: "flex",
                  gap: "0.4rem",
                  alignItems: "center",
                  fontSize: "0.95rem",
                  padding: "0.12rem 0",
                  borderBottom: "1px solid rgba(252,209,22,0.06)",
                  color: "rgba(252,209,22,0.4)",
                }}
              >
                <span style={{ color: "rgba(252,209,22,0.2)", width: "18px" }}>
                  {i + 1}.
                </span>
                <span
                  style={{
                    color: PLAYER_COLORS[(h.middle - 1) % PLAYER_COLORS.length],
                  }}
                >
                  {h.middle}
                </span>
                <span style={{ color: "rgba(252,209,22,0.2)" }}>vs</span>
                <span
                  style={{
                    color:
                      PLAYER_COLORS[(h.opponent - 1) % PLAYER_COLORS.length],
                  }}
                >
                  {h.opponent}
                </span>
                <span style={{ marginLeft: "auto", color: GH_GOLD }}>
                  {h.winnerIsMiddle ? `${h.middle} wins` : `${h.opponent} wins`}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        <div
          style={{
            display: "flex",
            height: "3px",
            borderRadius: "2px",
            overflow: "hidden",
            marginTop: "0.3rem",
          }}
        >
          <div style={{ flex: 1, background: GH_RED }} />
          <div style={{ flex: 1, background: GH_GOLD }} />
          <div style={{ flex: 1, background: GH_GREEN }} />
        </div>
        <div
          style={{
            fontSize: "0.82rem",
            color: "rgba(252,209,22,0.35)",
            textAlign: "center",
          }}
        >
          A puzzle by Emily Fleming inspired by the game of Ampe
        </div>
      </div>
    </div>
  );
}
